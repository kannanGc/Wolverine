## vue-orgchart

> A vue wrapper for OrgChart.js.

### 前言
- 首先感谢dabeng的Orgchart.js -- [OrgChart.js](https://github.com/dabeng/OrgChart.js)
- 如果你想用OrgChart.js的Vue封装，可以直接用 [我的项目](https://github.com/spiritree/vue-orgchart)

### 功能
- JSON格式导入导出树形关系图
- 支持树形关系图导出图片
- 可拖拉树形关系图
- 可编辑树形关系图

...
