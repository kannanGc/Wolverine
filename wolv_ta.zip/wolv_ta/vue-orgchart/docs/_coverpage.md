![logo](_assets/tree.svg)

# vue-orgchart <small>1.0.0</small>

> A Vue.js wrapper for OrgChart.js.

- Support import and export JSON
- Supports exporting chart as a picture
- Editable Orgchart


[GitHub](https://github.com/spiritree/vue-orgchart)
[Get Started](#vue-orgchart)


![color](#b3daff)
