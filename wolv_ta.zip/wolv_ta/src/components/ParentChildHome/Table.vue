<template>
<div   :class=" parentTable ? 'child':'groupHolder' " >
	<div :class="labelClasses" class="levelHolder" :style="indent" 	v-on:click="toggleChildren()">
  
    <span v-if="item.children" :class="iconClasses"></span>
    <span>{{item.table_name}}
    </span>

   </div> 
     <TableHolder
      v-for="childItem in item.children" 
      :item="childItem"
      v-if="showChildren"
      :parentTable="item.table_name" 
      :depth="depth + 1"  
    >
    </TableHolder>
 </div>   
 </template>   

 <script>

export default {
  name: 'TableHolder',
  props: {
  	item:Object,
  	parentTable:String,
  	depth:Number,
    children:Object,
  	parentDepth:Number
  },
  components: {
    
  },
  data: function(){
  return{
       showChildren: true,
    }
  },
  computed: {
  	indent() {
  	   return { marginLeft: `${this.depth * 150}px` }
  	 },
  	 moveParent(){
  		 return { width: `${5 * 150}px` }
  	 },
     labelClasses(){
        return { 'has-children': this.item.children }
     },
     iconClasses() {
        return {
          'plus-icon': !this.showChildren,
          'minus-icon': this.showChildren
        }  
      }
  },
  methods:{

    appendChild : function(evt){
      console.log("click");
    },
    toggleChildren() {
    	console.log("ll");
       this.showChildren = !this.showChildren;
    } 	
  },
  mounted() {
    console.log('test')
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

.levelHolder{
    width: 270px;
    border: 1px solid grey;
    margin-top: 30px;
    padding: 10px;
    margin-right: 35px;
    box-shadow: 5px 3px 15px 6px grey;

}
.tableName{
    padding: 10px;
    background: #8080804d;
    color: #231f1f;
    font-weight: bold;
    cursor:pointer;
    margin-top:10px;
}

.has-children {
      cursor: pointer;
}
.plus-icon{
  background-image:url('../../assets/add.png');
  width: 20px;
  height: 20px;
  background-size: 20px 20px;
  display: inline-block;
  float: left;
}
.minus-icon{
  background-image:url('../../assets/substract.png');
  width: 20px;
  height: 20px;
  background-size: 20px 20px;
  display: inline-block;
  float: left;
}
</style>
