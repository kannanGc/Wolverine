
<template>

 <div>
 <div class="heading"> Link Viewer </div>
    <vo-basic :data="chartData" :pan="true" :zoom="true"></vo-basic>
  </div>
</template>


<script>
import { VoBasic } from 'vue-orgchart'

export default {
  name: 'HelloWorld',
  props: {
    msg: String,
    children:Object,
  },
  components: {
    VoBasic
  },
  created () {
    this.chartData = {
      name: 'Master_table',
        children: [
          { name: 'table1' },
          {
            name: 'table1.1',
            children: [{ name: 'table1.1.1' }]
          },
          {

            name: 'table2',
            children: [{ name: 'table2.1' },{ name: 'table2.1' }]
          },{

            name: 'table2',
            children: [{ name: 'table2.1' },{ name: 'table2.1' }]
          },{

            name: 'table2',
            children: [{ name: 'table2.1' },{ name: 'table2.1' }]
          }
        ]
    }
  },
  data: function(){
  return{
      items: [

      ]
    }
  },
  methods:{

  },
  mounted() {
    this.$nextTick(function () {
    // Code that will run only after the
    // entire view has been rendered
/*    $("#parentChildHolder").HTMLSVGconnect({
      paths: [
        { start: "#levelHolder", end: "#child"}
      ]
    });*/


  })
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
#parentChildHolder{
  display:flex;
}
</style>
