
<template>

  <div id="parentChildHolder">
        <TableHolder v-for="item in items"
      :item="item"
       :depth="0"   
      :children="item.children" 
      :key="item.table_name">
      </TableHolder>
</div>
</template>


<script>
import TableHolder from './Table.vue'
import {HTMLSVGconnect} from 'html-svg-connect'

export default {
  name: 'HelloWorld',
  props: {
    msg: String,
    children:Object,
  },
  components: {
    TableHolder
  },
  data: function(){
  return{
      items: [
        { 
          table_name: 'Parent_Table_1',
          children:[
            {
              table_name: 'child_table_1',
              children: [
                {
                  table_name: 'child_table_1.1'
                },
                {
                  table_name: 'child_table_1.2',
                }
              ]
            },
            {
              table_name: 'child_table_12',
               children: [{
                  table_name: 'child_table_12.1',
                  children: [
                    {
                      table_name: 'child_table_12.1.1'
                    }
                  ]
                },{
                  table_name: 'child_table_12.2'
                }]
            }

          ]


        },{ 
          table_name: 'Parent_Table_2',
          children:[
           {
              table_name: 'child_table_2'
            }
          ]

        }
      ]
    }
  },
  methods:{

    
  },
  mounted() {
    this.$nextTick(function () {
    // Code that will run only after the
    // entire view has been rendered
/*    $("#parentChildHolder").HTMLSVGconnect({
      paths: [
        { start: "#levelHolder", end: "#child"}
      ]
    });*/


  })
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
#parentChildHolder{
  display:flex;
}
</style>
