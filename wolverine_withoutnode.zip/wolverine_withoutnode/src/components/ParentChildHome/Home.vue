<template>
  <div class="parentChildHolder">
        <TableHolder v-for="item in items"
      :item="item"
       :depth="0"   
      :key="item.table_name">
      </TableHolder>
</div>

</template>


<script>
import TableHolder from './Table.vue'

export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  components: {
    TableHolder
  },
  data: function(){
  return{
      items: [
        { 
          table_name: 'Parent_Table_1',
          children:[
            {
              table_name: 'child_table_1',
              children: [
                {
                  table_name: 'child_table_1.1',
                  children: []
                },{
                  table_name: 'child_table_1.2',
                  children: []
                }
              ]
            },
            {
              table_name: 'child_table_12',
               children: [{
                  table_name: 'child_table_12.1',
                  children: [
                    {
                      table_name: 'child_table_12.1.1',
                      children: [

                      ]
                      }
                  ]
                },{
                  table_name: 'child_table_12.2',
                  children: []
                }]
            }

          ]


        },{ 
          table_name: 'Parent_Table_2',
          children:[
           {
              table_name: 'child_table_2',
               children: []
            }
          ]

        }
      ]
    }
  },
  methods:{

    appendChild : function(evt){
      console.log("click");
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.parentChildHolder{
  display:flex;
}
</style>
