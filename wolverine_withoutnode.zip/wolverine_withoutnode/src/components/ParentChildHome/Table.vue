<template>
<div  :class=" parentTable ? 'child':'groupHolder' ">
	<div class="levelHolder" :style="indent">
      <div>{{item.table_name}}</div>
    </div>
     <TableHolder
      v-for="childItem in item.children" 
      :item="childItem"		
      :parentTable="item.table_name" 
      :depth="depth + 1"  
    >
    </TableHolder>
 </div>   
 </template>   

 <script>

export default {
  name: 'TableHolder',
  props: {
  	item:Object,
  	parentTable:String,
  	depth:Number,
  },
  components: {
    
  },
  data: function(){
  return{
      
    }
  },
  computed: {
	indent() {
	      return { transform: `translate(${this.depth * 150}px)` }
	    }
  },
  methods:{

    appendChild : function(evt){
      console.log("click");
    }

    
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.groupHolder{
	width:100%;
}
.levelHolder{
    width: 270px;
    border: 1px solid grey;
    margin-top: 30px;
    padding: 10px;
    box-shadow: 5px 3px 15px 6px grey;
}
.tableName{
    padding: 10px;
    background: #8080804d;
    color: #231f1f;
    font-weight: bold;
    cursor:pointer;
    margin-top:10px;
}


</style>
