<template>
  <div id="app">
    <parentChild msg="Welcome to Your Vue.js App"/>
  </div>
</template>

<script>
import parentChild from './components/ParentChildHome/Home.vue'
import TableHolder from './components/ParentChildHome/Table.vue'

export default {
  name: 'app',
  components: {
    parentChild
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
